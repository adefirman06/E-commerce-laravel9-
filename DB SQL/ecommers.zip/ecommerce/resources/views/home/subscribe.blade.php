 <section class="subscribe_section">
     <div class="container-fuild">
         <div class="box">
             <div class="row">
                 <div class="col-md-6 offset-md-3">
                     <div class="subscribe_form ">
                         <div class="heading_container heading_center">
                             <h3>Berlangganan untuk info terbaru</h3>
                         </div>
                         <p> Berlangganan untuk info Barang dan Diskon Terbaru dari kami</p>
                         <form action="">
                             <input type="email" placeholder="Masukan Email Anda">
                             <button>
                                 subscribe
                             </button>
                         </form>
                     </div>
                 </div>
             </div>
            
         </div>
     </div>
 </section>
 