<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style type="text/css">
        .div_center {
            text-align: center;
            padding-top: 40px;
        }

        .h2_font {
            font-size: 40px;
            padding-bottom: 40px;

        }

        .input_color {
            color: black;

        }

        #center {
            margin: auto;
            width: 50%;
            text-align: center;
            margin-top: 30px;
            border: 1px solid white;
            color: white;

        }

        td {
            padding: 10px;
            text-align: center;
        }

        th {
           
            text-align: center;
            color: black;
            font-family: bold;
        }

        thead {
            background-color: white;
            color: black;
        }

    </style>
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- partial -->
        <div class="main-panel">
            <div class="content-wrapper">
                <?php if(session()->has('message')): ?>

                <div class="alert alert-success">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    <?php echo e(session()->get('message')); ?>


                </div>
                <?php endif; ?>

                <div class="div_center">
                    <h2 class="h2_font"> Add Category</h2>

                    <form action="<?php echo e(url('/add_category')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <input class="input_color" type="text" name="category" placeholder="Masukan Nama Kategori">
                        <input type="submit" name="submit" class="btn btn-primary" value="Add Category">
                    </form>

                </div>

                <table id="center" class="table table-striped">

                    <thead>
                        <th>Nama Kategori</th>
                        <th>Action</th>
                    </thead>

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($data->category_name); ?></td>
                        <td>
                            <a onclick="return confirm('Yakin mau di hapus ?')" class="btn btn-danger" href="<?php echo e(url ('/delete_category',$data->id)); ?>"> Delete</a>
                            <a class="btn btn-primary" href="">Edit</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

            </div>
        </div>
        <!-- container-scroller -->
        <!-- plugins:js -->
        <!-- End custom js for this page -->
        <?php echo $__env->make('admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH /var/www/html/27/project workshop/ecommerce/resources/views/admin/category.blade.php ENDPATH**/ ?>