<section class="arrival_section">
    <div class="container">
        <div class="box">
            <div class="arrival_bg_box">
                <img src="images/arrival-bg.png" alt="">
            </div>
            <div class="row">
                <div class="col-md-6 ml-auto">
                    <div class="heading_container remove_line_bt">
                        <h2>
                            #NewArrivals
                        </h2>
                    </div>
                    <p style="margin-top: 20px;margin-bottom: 30px;">
                        kami hadir dengan membawa suasana baru dalan online shop,kami sudah bekerja sama dengan beragam penyedia barang dan jasa pengiriman diseluruh indonesia
                    </p>
                    <a href="">
                        Belanja Sekarang
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /var/www/html/27/project workshop/ecommerce/resources/views/home/new_arrival.blade.php ENDPATH**/ ?>