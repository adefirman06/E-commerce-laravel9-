<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"> -->
    <style type="text/css">
        .font1 {
            margin: auto;
            font-size: 30px;
        }

        .center {
            margin: auto;
            width: 50%;
        }

        h2 {
            text-align: center;
            font-size: 40px;
            color: white;
        }

        th {
            background-color: white;
            font-family: bold;
        }

        td {
            color: white;
        }
    </style>

</head>

<body>
    <div class="container-scroller" style="margin: auto;">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- partial -->


        <div class="main-panel" style="margin: auto;">
            <div class="content-wrapper" style="margin: auto;">
                <h1 class=" font1"> Daftar Produk</h1>
                <?php if(session()->has('message')): ?>

                <div class="alert alert-success">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    <?php echo e(session()->get('message')); ?>


                </div>
                <?php endif; ?>

                <table class="table table-bordered table-dark" style="margin: auto;">
                    <thead>
                        <tr>
                            <th>Nama Produk</th>
                            <th>Deskripsi</th>
                            <th>Kuantitas</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th>Potongan Harga</th>
                            <th>Gambar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->title); ?></td>
                            <td><?php echo e($product->description); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td><?php echo e($product->category); ?></td>
                            <td>Rp. <?php echo number_format($product->price,0,',','.'); ?></td>
                            <td><?php echo e($product->discount_price); ?></td>
                            <td>
                                <img sco src=" /product/<?php echo e($product->image); ?>">
                    </td>
                    <td>
                        <a onclick="return confirm('Yakin mau di hapus ?')" class="btn btn-danger" href="<?php echo e(url('delete_product',$product->id)); ?>">Hapus</a>
                        <a class="btn btn-success" href="<?php echo e(url('update_product',$product->id)); ?>">Edit</a>
                    </td>




                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>


        </div>
        <!-- container-scroller -->
        <!-- plugins:js -->
        <!-- End custom js for this page -->
    </div>
    <?php echo $__env->make('admin.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>

</html><?php /**PATH /var/www/html/27/project workshop/ecommerce/resources/views/admin/show_product.blade.php ENDPATH**/ ?>